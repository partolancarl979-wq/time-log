let count = 0;
const logTable = document.querySelector('#logTable tbody');

document.getElementById('timeInBtn').onclick = () => addLog('Time In / Log-in');
document.getElementById('timeOutBtn').onclick = () => addLog('Time Out / Log-out');

function addLog(action) {
  count++;
  const row = document.createElement('tr');
  row.innerHTML = `<td>${count}</td><td>${action}</td><td>${new Date().toLocaleString()}</td>`;
  logTable.appendChild(row);
}
